//
//  Valify.h
//  Valify
//
//  Created by Mina Atef on 19/08/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for Valify.
FOUNDATION_EXPORT double ValifyVersionNumber;

//! Project version string for Valify.
FOUNDATION_EXPORT const unsigned char ValifyVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Valify/PublicHeader.h>


